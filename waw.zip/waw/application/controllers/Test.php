<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {
	



	public function index()
{
	$this->load->view('Welcome_message');
}
public function CV1(){
	$this->load->view('CV1');
	}
	public function tabel(){
		$this->load->view('tabel');
	}
}